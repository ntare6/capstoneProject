df = pd.get_dummies(df, columns=['Class'], drop_first=False)
