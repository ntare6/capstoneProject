import matplotlib.pyplot as plt
import seaborn as sns

plt.figure(figsize=(15,12))
sns.heatmap(df.corr(), annot=False, cmap='coolwarm', linewidths=0.5)
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.show()
