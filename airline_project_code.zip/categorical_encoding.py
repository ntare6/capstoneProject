from sklearn.preprocessing import LabelEncoder

label_cols = ['Gender', 'Customer Type', 'Type of Travel', 'Satisfaction']
le = LabelEncoder()
for col in label_cols:
    df[col] = le.fit_transform(df[col])
