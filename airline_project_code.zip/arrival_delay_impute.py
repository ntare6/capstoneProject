# Fill missing Arrival Delay values with median
median_value = df['Arrival Delay'].median()
df['Arrival Delay'] = df['Arrival Delay'].fillna(median_value)
