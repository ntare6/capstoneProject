df.to_csv('cleaned_airline_data.csv', index=False)
