def label_encode(df, column_name, positive_class):
    df[column_name] = df[column_name].apply(lambda x: 1 if x == positive_class else 0)
